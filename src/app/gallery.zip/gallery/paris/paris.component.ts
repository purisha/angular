import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paris',
  templateUrl: './paris.component.html',
  styleUrls: ['./paris.component.css']
})
export class ParisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
