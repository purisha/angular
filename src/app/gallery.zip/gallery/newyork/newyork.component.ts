import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newyork',
  templateUrl: './newyork.component.html',
  styleUrls: ['./newyork.component.css']
})
export class NewyorkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
