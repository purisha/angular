import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-address',
  templateUrl: './book-address.component.html',
  styleUrls: ['./book-address.component.css']
})
export class BookAddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
